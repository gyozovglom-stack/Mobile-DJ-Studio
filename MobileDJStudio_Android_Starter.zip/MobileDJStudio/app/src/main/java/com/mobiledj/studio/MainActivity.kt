package com.mobiledj.studio

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF151A23)
private val Panel2 = Color(0xFF202735)
private val AccentA = Color(0xFF36C5F0)
private val AccentB = Color(0xFFFF8A4C)
private val TextMain = Color(0xFFF3F6FA)
private val TextMuted = Color(0xFF8D9AAA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MobileDJApp() }
    }
}

private class DeckPlayer {
    private var player: MediaPlayer? = null
    var title by mutableStateOf("No track loaded")
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var duration by mutableIntStateOf(0)
        private set
    var position by mutableIntStateOf(0)
        private set
    var gain by mutableFloatStateOf(0.85f)

    fun load(context: android.content.Context, uri: Uri) {
        release()
        player = MediaPlayer().apply {
            setDataSource(context, uri)
            setOnPreparedListener {
                duration = it.duration.coerceAtLeast(0)
                position = 0
                it.setVolume(gain, gain)
            }
            setOnCompletionListener { isPlaying = false; position = 0 }
            prepareAsync()
        }
        title = uri.lastPathSegment?.substringAfterLast('/') ?: "Loaded track"
    }

    fun toggle() {
        val p = player ?: return
        if (p.isPlaying) { p.pause(); isPlaying = false }
        else { p.start(); isPlaying = true }
    }

    fun seekTo(value: Int) {
        val p = player ?: return
        p.seekTo(value.coerceIn(0, duration))
        position = value.coerceIn(0, duration)
    }

    fun setGain(value: Float) {
        gain = value.coerceIn(0f, 1f)
        player?.setVolume(gain, gain)
    }

    fun tick() {
        val p = player ?: return
        if (p.isPlaying) position = p.currentPosition
    }

    fun release() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        isPlaying = false
        duration = 0
        position = 0
    }
}

@Composable
private fun MobileDJApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val deckA = remember { DeckPlayer() }
    val deckB = remember { DeckPlayer() }
    var crossfader by remember { mutableFloatStateOf(0.5f) }
    var master by remember { mutableFloatStateOf(0.9f) }
    var activeTab by remember { mutableStateOf("MIXER") }

    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) {
            try { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            deckA.load(context, it)
        }
    }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) {
            try { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            deckB.load(context, it)
        }
    }

    LaunchedEffect(Unit) {
        while (true) { deckA.tick(); deckB.tick(); delay(250) }
    }
    DisposableEffect(Unit) {
        onDispose { deckA.release(); deckB.release() }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = AccentA,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MOBILE DJ", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("STUDIO  •  PRO MIXER", color = TextMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Surface(color = Color(0xFF173B35), shape = RoundedCornerShape(20.dp)) {
                    Text("● READY", color = Color(0xFF63E6BE), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DeckCard("A", AccentA, deckA, modifier = Modifier.weight(1f), onLoad = { pickA.launch(arrayOf("audio/*")) })
                DeckCard("B", AccentB, deckB, modifier = Modifier.weight(1f), onLoad = { pickB.launch(arrayOf("audio/*")) })
            }

            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("MASTER MIXER", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.2.sp)
                        Text("OUTPUT", color = TextMuted, fontSize = 10.sp)
                    }
                    Text("CROSSFADER", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("A", color = AccentA, fontWeight = FontWeight.Bold)
                        Slider(value = crossfader, onValueChange = {
                            crossfader = it
                            deckA.setGain((1f - it) * master)
                            deckB.setGain(it * master)
                        }, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = TextMain, activeTrackColor = AccentA, inactiveTrackColor = Panel2))
                        Text("B", color = AccentB, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("MASTER", color = TextMuted, fontSize = 9.sp, modifier = Modifier.width(55.dp))
                        Slider(value = master, onValueChange = {
                            master = it
                            deckA.setGain((1f - crossfader) * master)
                            deckB.setGain(crossfader * master)
                        }, modifier = Modifier.weight(1f))
                        Text("${(master * 100).toInt()}%", color = TextMain, fontSize = 10.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("LIBRARY", "MIXER", "FX", "RECORD").forEach { tab ->
                    TextButton(onClick = { activeTab = tab }) {
                        Text(tab, color = if (activeTab == tab) AccentA else TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (activeTab != "MIXER") {
                Text(
                    when (activeTab) {
                        "LIBRARY" -> "LIBRARY: загрузка треков доступна через кнопки LOAD на деках."
                        "FX" -> "FX: следующий этап — фильтр, echo, reverb и эффекты."
                        else -> "RECORD: запись микса добавим в следующем этапе."
                    },
                    color = TextMuted, fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun DeckCard(
    name: String,
    accent: Color,
    deck: DeckPlayer,
    modifier: Modifier = Modifier,
    onLoad: () -> Unit
) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = modifier.fillMaxHeight()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("DECK $name", color = accent, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text("●", color = if (deck.isPlaying) Color(0xFF63E6BE) else TextMuted, fontSize = 10.sp)
            }
            Box(
                Modifier.fillMaxWidth().weight(1f).aspectRatio(1f).clip(CircleShape)
                    .background(Color(0xFF080A0F)), contentAlignment = Alignment.Center
            ) {
                Box(Modifier.fillMaxSize(0.88f).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxSize(0.82f).clip(CircleShape).background(Color(0xFF111722)), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("DJ", color = accent, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            Text(name, color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
            Text(deck.title, color = TextMain, fontSize = 10.sp, maxLines = 1)
            Text("${formatTime(deck.position)} / ${formatTime(deck.duration)}", color = TextMuted, fontSize = 9.sp)
            Slider(
                value = if (deck.duration > 0) deck.position.toFloat() / deck.duration else 0f,
                onValueChange = { deck.seekTo((it * deck.duration).toInt()) },
                colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Button(onClick = onLoad, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                    Text("LOAD", fontSize = 10.sp)
                }
                Button(onClick = { deck.toggle() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                    Text(if (deck.isPlaying) "PAUSE" else "PLAY", color = Bg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun formatTime(ms: Int): String {
    val seconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
