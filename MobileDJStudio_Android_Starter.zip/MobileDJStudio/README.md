# Mobile DJ Studio — Android starter

Первый рабочий каркас нативного Android-приложения на Kotlin + Jetpack Compose.

## Уже заложено
- Две независимые аудиодеки
- Импорт локальных аудиофайлов через системный выбор файлов
- Play / Pause и перемотка
- Crossfader A/B и общий уровень громкости
- Тёмный интерфейс, адаптированный под телефон

## Сборка
1. Установите Android Studio (актуальную стабильную версию).
2. Откройте папку `MobileDJStudio` как Gradle project.
3. Дождитесь синхронизации Gradle.
4. Подключите Android-телефон с включённой USB-отладкой или используйте эмулятор.
5. Нажмите Run.

Для APK: Build → Build Bundle(s) / APK(s) → Build APK(s).

## Важно
Это стартовая версия 0.1.0. Следующие этапы: корректное применение crossfader без конфликта с индивидуальной громкостью дек, BPM analysis, waveform, cue/loops, EQ и эффекты, запись микса, низколатентный аудиодвижок. Текущая реализация использует Android MediaPlayer как прототип; для профессиональной задержки и точного сведения потребуется отдельный аудиодвижок.


## Cloud APK build
The repository includes `.github/workflows/android.yml`. After uploading the project to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build Mobile DJ Studio APK**.
3. Tap **Run workflow** (or let the first push start the workflow).
4. Open the completed run and download the `Mobile-DJ-Studio-debug` artifact.
